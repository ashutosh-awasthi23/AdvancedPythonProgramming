# Base Class
class MusicalInstrument:
    def __init__(self, name, type):
        self._name = name
        self._type = type
        self._is_tuned = False

    def play(self):
        print(f"The {self._name} is being played.")

    def tune(self):
        self._is_tuned = True
        print(f"The {self._name} is tuned.")

    def check_tuning(self):
        status = "tuned" if self._is_tuned else "not tuned"
        print(f"The {self._name} is currently {status}.")

    # Getter for _name
    @property
    def name(self):
        return self._name

    # Setter for _name
    @name.setter
    def name(self, value):
        self._name = value

    # Getter for _type
    @property
    def type(self):
        return self._type

    # Setter for _type
    @type.setter
    def type(self, value):
        self._type = value


# Subclasses
class Guitar(MusicalInstrument):
    def __init__(self, name, number_of_strings):
        super().__init__(name, type="String")
        self.number_of_strings = number_of_strings

    def play(self):
        print(f"The guitar is strumming.")

class Piano(MusicalInstrument):
    def __init__(self, name, number_of_keys):
        super().__init__(name, type="String")
        self.number_of_keys = number_of_keys

    def play(self):
        print(f"The piano is playing.")

class Drum(MusicalInstrument):
    def __init__(self, name, drum_size):
        super().__init__(name, type="Percussion")
        self.drum_size = drum_size

    def play(self):
        print(f"The drum is being beaten.")


# Polymorphism function
def test_instruments(instruments):
    for instrument in instruments:
        instrument.play()
        instrument.check_tuning()


# Demonstration Code
if __name__ == "__main__":
    # Instantiate the objects
    guitar = Guitar(name="Acoustic Guitar", number_of_strings=6)
    piano = Piano(name="Grand Piano", number_of_keys=88)
    drum = Drum(name="Bass Drum", drum_size="Large")

    # Call the tune() method for each instrument
    guitar.tune()
    piano.tune()
    drum.tune()

    # Create a list of instruments
    instruments = [guitar, piano, drum]

    # Use the test_instruments function
    test_instruments(instruments)

    # Demonstrate encapsulation
    print("\nEncapsulation demonstration:")
    print(f"Guitar name: {guitar.name}")
    guitar.name = "Electric Guitar"
    print(f"Updated Guitar name: {guitar.name}")

    # Attempting to directly access private attributes (which is discouraged)
    try:
        print(guitar._name)  # Direct access to private attribute (not recommended)
    except AttributeError as e:
        print(f"Error: {e}")

    try:
        guitar._name = "Updated Name"  # Direct modification of private attribute (not recommended)
        print(f"Updated Guitar name via direct access: {guitar._name}")
    except AttributeError as e:
        print(f"Error: {e}")
